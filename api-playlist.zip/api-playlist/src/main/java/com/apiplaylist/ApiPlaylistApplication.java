package com.apiplaylist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPlaylistApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiPlaylistApplication.class, args);
	}

}
